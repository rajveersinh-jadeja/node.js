const Movie = require('../models/movieModel');

exports.getMovies = async (req, res) => {
    try {
        const search = req.query.search || '';
        const genre = req.query.genre || '';

        let query = {};
        if (search) {
            query.title = { $regex: search, $options: 'i' };
        }
        if (genre) {
            query.genre = genre;
        }

        const movies = await Movie.find(query);
        res.render('movies/list', { movies, search, genre });
    } catch (err) {
        console.log(err);
        res.status(500).send("Server Error");
    }
};


exports.getAddMovie = (req, res) => {
    res.render('movies/add');
};


exports.postAddMovie = async (req, res) => {
    try {
        await Movie.create(req.body);
        res.redirect('/');
    } catch (err) {
        console.log(err);
        res.status(500).send("Error adding movie");
    }
};


exports.getMovieDetails = async (req, res) => {
    try {
        const movie = await Movie.findById(req.params.id);
        res.render('movies/details', { movie });
    } catch (err) {
        console.log(err);
        res.status(404).send("Movie not found");
    }
};


exports.getEditMovie = async (req, res) => {
    try {
        const movie = await Movie.findById(req.params.id);
        res.render('movies/edit', { movie });
    } catch (err) {
        console.log(err);
        res.status(404).send("Movie not found");
    }
};


exports.postEditMovie = async (req, res) => {
    try {
        await Movie.findByIdAndUpdate(req.params.id, req.body);
        res.redirect(`/movies/${req.params.id}`);
    } catch (err) {
        console.log(err);
        res.status(500).send("Error updating movie");
    }
};


exports.deleteMovie = async (req, res) => {
    try {
        await Movie.findByIdAndDelete(req.params.id);
        res.redirect('/');
    } catch (err) {
        console.log(err);
        res.status(500).send("Error deleting movie");
    }
};