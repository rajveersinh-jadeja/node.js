const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const movieRoutes = require('./routes/movieRoutes');

const app = express();


mongoose.connect('mongodb://127.0.0.1:27017/movieDB')
    .then(() => console.log('Connected to MongoDB'))
    .catch(err => console.log(err));

app.set('view engine', 'ejs');

app.set('views', path.join(__dirname, 'views'));


app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));


app.use('/', movieRoutes);


app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});