const express = require('express');
const router = express.Router();
const movieController = require('../controllers/movieController');

router.get('/', movieController.getMovies);
router.get('/movies/add', movieController.getAddMovie);
router.post('/movies/add', movieController.postAddMovie);
router.get('/movies/:id', movieController.getMovieDetails);
router.get('/movies/edit/:id', movieController.getEditMovie);
router.post('/movies/edit/:id', movieController.postEditMovie);
router.post('/movies/delete/:id', movieController.deleteMovie);

router.get('/index', (req, res) => {
    res.render('index');
});

defaultViews = router;
module.exports = router;