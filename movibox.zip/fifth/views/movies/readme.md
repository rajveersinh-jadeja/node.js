# 🎬 Movie Management System

## 📌 Project Description
The **Movie Management System** is a full-stack web application developed using the Model-View-Controller (MVC) architecture with Node.js, Express, and EJS. It allows users to manage a collection of movies efficiently with complete **CRUD (Create, Read, Update, Delete)** operations, backed by MongoDB.

---
# 📁 Complete Project Directory Structure


fifth/
│
├── controllers/
│   └── movieController.js    
├── models/
│   └── movieModel.js          
├── public/
│   ├── css/
│   │   └── style.css       
│   └── images/                
├── routes/
│   └── movieRoutes.js       
├── views/
│   ├── movies/
│   │   ├── add.ejs            
│   │   ├── details.ejs      
│   │   ├── edit.ejs           
│   │   └── list.ejs          
│   └── index.ejs             
├── app.js                     
├── package-lock.json          
└── package.json

## 🛠️ Technology Used
* **Frontend:** EJS (Embedded JavaScript), HTML5, CSS3
* **Backend:** Node.js, Express.js
* **Database & ODM:** MongoDB, Mongoose
* **Architecture:** Model-View-Controller (MVC) Pattern

---

## ✨ Project Features
* **Home Landing Page:** Welcome interface with quick navigation options.
* **Movie Collection List:** View all movies in a responsive grid layout with a built-in search bar.
* **Add New Movie:** Form interface to insert new movie records into the database.
* **Movie Details View:** Inspect comprehensive details (description, genre, release year, duration, language, director, cast, and rating) for any selected movie.
* **Edit & Update Movie:** Pre-filled form interface to modify existing records.
* **Delete Movie:** Option to remove unwanted records with a confirmation prompt.

---

## ⚙️ Database Configuration
1. Ensure your local MongoDB service is running on your machine.
2. The application connects via Mongoose to the local database string specified in `app.js`:
   ```javascript
   mongodb://127.0.0.1:27017/movieDB

   ## 📸 Screenshots

* **1. Home Page (`index.ejs`):**


* **2. Movie Collection List (`list.ejs`):**
* ![Movie List](public/images/screenshot-list.png)
  

* **3. Add Movie Form (`add.ejs`):**
  

* **4. Movie Details Page (`details.ejs`):**
  >

* **5. Edit Movie Form (`edit.ejs`):**
  